﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace StudentRegistration
{
    public class RegistrationForm : Form
    {
        // Defination elements of the Form: Name, Email, Gender ...etc
        private Label lblName;
        private TextBox txtName;

        private Label lblEmail;
        private TextBox txtEmail;

        private Label lblPassword;
        private TextBox txtPassword;

        private Label lblGender;
        private RadioButton rbMale;
        private RadioButton rbFemale;

        private Label lblFavoriteColor;
        private Button btnChooseColor;
        private Color favoriteColor = Color.Black; // Default Color Black

        private Label lblBirthdate;
        private DateTimePicker dtpBirthdate;

        private Label lblCountry;
        private ComboBox cmbCountry;

        private Button btnRegister;
        private Label lblResult;

        private ColorDialog colorDialog1;

        public RegistrationForm()
        {
            // Properties Of The Form
            this.Text = "Student Registration Form";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = ColorTranslator.FromHtml("#123456");
            // Setting ColorDialog
            colorDialog1 = new ColorDialog();

            // Setting and Initialization all of elements of the Form
            InitializeControls();
        }


        private void InitializeControls()
        {
            // User Name
            lblName = new Label() { Text = "Name:", Location = new Point(30, 30), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblName.ForeColor = Color.YellowGreen;
            txtName = new TextBox() { Location = new Point(160, 30), Width = 200};

            // Email with veriviation of correct Expression
            lblEmail = new Label() { Text = "Email:", Location = new Point(30, 70), Font =  new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblEmail.ForeColor = Color.YellowGreen;
            txtEmail = new TextBox() { Location = new Point(160, 70), Width = 200 };

            // Password with hidden
            lblPassword = new Label() { Text = "Password:", Location = new Point(30, 110), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblPassword.ForeColor = Color.YellowGreen;
            txtPassword = new TextBox() { Location = new Point(160, 110), Width = 200, PasswordChar = '*' };

            // Gender: Male or Female
            lblGender = new Label() { Text = "Gender:", Location = new Point(30, 150), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblGender.ForeColor = Color.YellowGreen;
            rbMale = new RadioButton() { Text = "Male", Location = new Point(160, 150), Font = new Font("Tahoma", 10, FontStyle.Bold), AutoSize = true };
            rbMale.ForeColor = Color.Wheat;
            rbFemale = new RadioButton() { Text = "Female", Location = new Point(230, 150), Font = new Font("Tahoma", 10, FontStyle.Bold), AutoSize = true };
            rbFemale.ForeColor = Color.Wheat;

            // Favorate Color using ColorDialog
            lblFavoriteColor = new Label() { Text = "Favorite Color:", Location = new Point(30, 190), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            btnChooseColor = new Button() { Text = "Choose Color", Location = new Point(160, 180), Width = 100, Height = 30 };
            btnChooseColor.BackColor = Color.YellowGreen;
            btnChooseColor.Click += BtnChooseColor_Click;
            lblFavoriteColor.ForeColor = Color.YellowGreen;

            // Birthday using DateTimePicker
            lblBirthdate = new Label() { Text = "Birthdate:", Location = new Point(30, 230), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblBirthdate.ForeColor = Color.YellowGreen;
            dtpBirthdate = new DateTimePicker() { Location = new Point(160, 230), Width = 200, Height = 60 };

            // Choosing country using comboBox
            lblCountry = new Label() { Text = "Country:", Location = new Point(30, 270), Font = new Font("Tahoma", 12, FontStyle.Bold), AutoSize = true };
            lblCountry.ForeColor = Color.YellowGreen;
            cmbCountry = new ComboBox() { Location = new Point(160, 270), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            
            // Adding some Countries
            cmbCountry.Items.AddRange(new string[] { "Yemen", "USA", "UAE", "Egypt", "Saudi Arabia" });
            if (cmbCountry.Items.Count > 0)
                cmbCountry.SelectedIndex = 0;

            // Registration Button
            btnRegister = new Button() { Text = "Register", Font = new Font("Tahoma", 12, FontStyle.Bold), Location = new Point(160, 320), Width = 130, Height = 60 };
            btnRegister.BackColor = Color.OrangeRed;
            btnRegister.Click += BtnRegister_Click;

            // Show data after clicking the registr button
            lblResult = new Label() { Text = "", Location = new Point(30, 400), AutoSize = true, Font = new Font("Arial", 10, FontStyle.Bold) };
            lblResult.ForeColor = Color.Wheat;

            // Adding all of elements to Form
            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(lblEmail);
            this.Controls.Add(txtEmail);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(lblGender);
            this.Controls.Add(rbMale);
            this.Controls.Add(rbFemale);
            this.Controls.Add(lblFavoriteColor);
            this.Controls.Add(btnChooseColor);
            this.Controls.Add(lblBirthdate);
            this.Controls.Add(dtpBirthdate);
            this.Controls.Add(lblCountry);
            this.Controls.Add(cmbCountry);
            this.Controls.Add(btnRegister);
            this.Controls.Add(lblResult);
        }

        // Choosing Color Event
        private void BtnChooseColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                favoriteColor = colorDialog1.Color;
                btnChooseColor.BackColor = favoriteColor;
            }
        }

        // Pressing Registration Button Event
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            // Validate Email Using Regular Expression
            if (!Regex.IsMatch(txtEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Select The Choosen Gender
            string gender = "";
            if (rbMale.Checked)
                gender = "Male";
            else if (rbFemale.Checked)
                gender = "Female";

            // Details Of Registration
            string details = string.Format("{0}, {1}, {2}, Favorite Color: {3}, Birthdate: {4}, Country: {5}",
                txtName.Text,
                txtEmail.Text,
                gender,
                favoriteColor.IsEmpty ? "None" : favoriteColor.Name,
                dtpBirthdate.Value.ToShortDateString(),
                cmbCountry.SelectedItem.ToString());

            lblResult.Text = details;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // RegistrationForm
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            this.ResumeLayout(false);

        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }
    }
}